var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["8cf77057-a95a-499b-86ad-aaaa8cdea646"],"propsByKey":{"8cf77057-a95a-499b-86ad-aaaa8cdea646":{"name":"WIN","sourceUrl":null,"frameSize":{"x":48,"y":32},"frameCount":1,"looping":true,"frameDelay":12,"version":"jWqf7VnUL2XmzMEpnA77aPnSsjdT24fP","loadedFromSource":true,"saved":true,"sourceSize":{"x":48,"y":32},"rootRelativePath":"assets/8cf77057-a95a-499b-86ad-aaaa8cdea646.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

  var WIN = createSprite(330,190,240,135);
  
  WIN.setAnimation("WIN");
  WIN.scale="1.2";
  
  var backbackground = createSprite(190,190,240,135);
  backbackground.shapeColor="white";
  
  var wall1 = createSprite(190,120,250,5);
  wall1.shapeColor="black";
  var wall2 = createSprite(190,260,250,5);
  wall2.shapeColor="black";
  var wall3 = createSprite(67,145,3,50);
  wall3.shapeColor="black";
  var wall4 = createSprite(67,235,3,50);
  wall4.shapeColor="black";
  var wall5 = createSprite(313,145,3,50);
  wall5.shapeColor="black";
  var wall6 = createSprite(313,235,3,50);
  wall6.shapeColor="black";
  var wall7 = createSprite(41,170,50,3);
  wall7.shapeColor="black";
  var wall8 = createSprite(41,210,50,3);
  wall8.shapeColor="black";
  var wall9 = createSprite(337,210,50,3);
  wall9.shapeColor="black";
  var wall10 = createSprite(337,170,50,3);
  wall10.shapeColor="black";
  var wall11 = createSprite(18,190,3,40);
  wall11.shapeColor="black";
  var wall12 = createSprite(361,190,3,40);
  wall12.shapeColor="black";
  
  var player = createSprite(40,190,13,13);
  player.shapeColor = "#0023FF";
  
  var enemi1 = createSprite(100,130,10,10);
  enemi1.shapeColor = "red";
  var enemi2 = createSprite(215,130,10,10);
  enemi2.shapeColor = "red";
  var enemi3 = createSprite(165,250,10,10);
  enemi3.shapeColor = "red";
  var enemi4 = createSprite(270,250,10,10);
  enemi4.shapeColor = "red";
  
 enemi1.velocityY = 8;
 enemi2.velocityY = 8;
  enemi3.velocityY = -8;
  enemi4.velocityY = -8;
  
  var count = 0;
  
  playSound("assets/sound123.mp3", true);







function draw() {
  background("#B0C9FF");
  fill("black");
  textSize(20);
  textFont("Arial");
  text("💀DEATHS💀: " + count,200,100);
  strokeWeight(0);
  fill("lightblue");
  rect(18,170,52,40);
  rect(308,170,52,40);
  
  enemi1.bounceOff(wall1);
  enemi1.bounceOff(wall2);
 enemi2.bounceOff(wall1);
 enemi2.bounceOff(wall2);
 enemi3.bounceOff(wall1);
  enemi3.bounceOff(wall2);
  enemi4.bounceOff(wall1);
  enemi4.bounceOff(wall2);
  
 
  if(keyDown("right")){
    player.x = player.x + 2;
  }
  if(keyDown("left")){
    player.x = player.x - 2;
  }
  player.collide(wall1);
player.collide(wall2);
player.collide(wall3);
player.collide(wall4);
player.collide(wall5);
player.collide(wall6);
player.collide(wall7);
player.collide(wall8);
player.collide(wall9);
player.collide(wall10);
player.collide(wall11);
player.collide(wall12);
   
  if(keyDown("down")){
    player.y = player.y + 2;
  }
  if(keyDown("up")){
    player.y = player.y - 2;
  }
  
  if(
     player.isTouching(enemi1)||
     player.isTouching(enemi2)||
     player.isTouching(enemi3)||
     player.isTouching(enemi4))
  {
     player.x = 40;
     player.y = 190;
     count = count + 1;
  }
  
 if (player.isTouching(WIN)) {
   
   fill("#FF0078");
   
   stroke("black");
   strokeWeight(10);
   
   textSize(40);
   text("😮U WIN👌", 70, 350);
   
 }
 
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
 drawSprites();
}
























// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
